package redis.clients.jedis.commands;

public interface ProtocolCommand {

  byte[] getRaw();

}
